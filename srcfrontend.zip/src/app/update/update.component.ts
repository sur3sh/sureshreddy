import { Component } from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent {

  data:any;
  constructor(private s1:StudentService) { }

  ngOnInit(): void {
  let response = this.s1.viewservice();
  response.subscribe((data1: any)=>this.data=data1)

  }

  updatedata(updateform:{value:any;})
  {
     return this.s1.updateservice(updateform.value).subscribe();
  }
}
